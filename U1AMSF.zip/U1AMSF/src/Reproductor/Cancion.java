package U1AMSF;

/** * * @author Raul */
public class Cancion extends Artista {
    private String fecha, nombre_cancion;
    private int duracion;

    public Cancion() {
    }

    public Cancion(Artista ar,String fecha, String nombre_cancion, int duracion) {
        super(ar.getNombre(), ar.getGenero(), ar.getEdad());
        this.fecha = fecha;
        this.nombre_cancion = nombre_cancion;
        this.duracion = duracion;
    }

    public Cancion(String fecha, String nombre_cancion, int duracion, String nombre, String genero, int edad) {
        super(nombre, genero, edad);
        this.fecha = fecha;
        this.nombre_cancion = nombre_cancion;
        this.duracion = duracion;
    }
    
    public void mostrarCancion(){
        System.out.println("Artista: "+this.getNombre());
        System.out.println("Genero: "+this.getGenero());
        System.out.println("Cancion: "+this.getNombre_cancion());
        System.out.println("Duracion: "+this.getDuracion());
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getNombre_cancion() {
        return nombre_cancion;
    }

    public void setNombre_cancion(String nombre_cancion) {
        this.nombre_cancion = nombre_cancion;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }
    
    
}
