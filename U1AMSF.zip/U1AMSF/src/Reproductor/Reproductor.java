package Reproductor;

import U1AMSF.Artista;
import U1AMSF.Cancion;
import java.util.ArrayDeque;
import java.util.Deque;

/** *
 * @author Admin
 */
public class Reproductor {

    public static void main(String[] args) {
        Artista a1 = new Artista("Cartel de santa", "Rap", 45);
        Artista a2 = new Artista("Santa fe clan", "Rap", 20);
        
        Cancion c1 = new Cancion(a1, "fecha", "nombre_cancion", 240);
        Cancion c2 = new Cancion(a1, "fecha", "nombre_cancion", 300);
        
        Deque<Cancion> pila1 = new ArrayDeque<>();
        pila1.push(c2);
        
    }
    
}
